CREATE TABLE operadoras (
    registro_ans VARCHAR(20) PRIMARY KEY,
    cnpj VARCHAR(18) UNIQUE NOT NULL,
    razao_social TEXT NOT NULL,
    nome_fantasia TEXT,
    modalidade VARCHAR(100),
    logradouro TEXT,
    numero VARCHAR(20),
    complemento TEXT,
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    uf CHAR(2),
    cep VARCHAR(10),
    ddd VARCHAR(3),
    telefone VARCHAR(20),
    email TEXT,
    representante TEXT,
    cargo_representante TEXT,
    data_registro_ans DATE
);

CREATE INDEX idx_operadoras_cnpj ON operadoras(cnpj);

CREATE TABLE despesas_consolidadas (
    id SERIAL PRIMARY KEY,
    cnpj VARCHAR(18) NOT NULL,
    razao_social TEXT,
    trimestre INT CHECK (trimestre BETWEEN 1 AND 4),
    ano INT,
    valor_despesa NUMERIC(18, 2),
    status VARCHAR(50),
  
    CONSTRAINT fk_operadora FOREIGN KEY (cnpj) REFERENCES operadoras(cnpj)
);

CREATE INDEX idx_despesas_cnpj_ano ON despesas_consolidadas(cnpj, ano);
CREATE INDEX idx_despesas_status ON despesas_consolidadas(status);

CREATE TABLE despesas_agregadas (
    razao_social TEXT PRIMARY KEY,
    uf CHAR(2),
    total_despesas NUMERIC(25, 2),
    media_trimestral NUMERIC(18, 2),
    desvio_padrao_despesas NUMERIC(18, 2)
);

CREATE INDEX idx_agregadas_uf ON despesas_agregadas(uf);

SELECT 
    status, 
    count(*) as quantidade, 
    SUM(valor_despesa) as total_valor
FROM despesas_consolidadas
GROUP BY status;

CREATE TEMP TABLE stage_despesas (
    cnpj TEXT,
    razao_social TEXT,
    trimestre TEXT,
    ano TEXT,
    valor_despesa TEXT,
    status TEXT
);

CREATE TABLE IF NOT EXISTS stage_despesas (
    cnpj TEXT,
    razao_social TEXT,
    trimestre TEXT,
    ano TEXT,
    valor_despesa TEXT,
    status TEXT
);

DROP TABLE IF EXISTS despesas_consolidadas;

CREATE TABLE despesas_consolidadas (
    id SERIAL PRIMARY KEY,
    cnpj VARCHAR(20),
    razao_social TEXT, 
    trimestre INT,
    ano INT,
    valor_despesa NUMERIC(18, 2),
    status TEXT
);

INSERT INTO despesas_consolidadas (cnpj, razao_social, trimestre, ano, valor_despesa, status)
SELECT 
    
    REGEXP_REPLACE(cnpj, '[^0-9]', '', 'g'),
    
    COALESCE(razao_social, 'NOME NÃO INFORMADO'),
    
    CAST(NULLIF(trimestre, '') AS INTEGER),
    CAST(NULLIF(ano, '') AS INTEGER),
    
    CAST(REPLACE(COALESCE(NULLIF(valor_despesa, ''), '0'), ',', '.') AS NUMERIC),
    
    COALESCE(status, 'Sem Status')
FROM stage_despesas;

SELECT cnpj, razao_social, valor_despesa 
FROM despesas_consolidadas 
WHERE cnpj IS NOT NULL 
LIMIT 5;

SELECT count(*) FROM stage_despesas;

INSERT INTO despesas_consolidadas (cnpj, razao_social, trimestre, ano, valor_despesa, status)
SELECT 
    
    REGEXP_REPLACE(cnpj, '[^0-9]', '', 'g'),
    
    COALESCE(razao_social, 'NOME NÃO INFORMADO'),
    
    NULLIF(trimestre, '')::INTEGER,
    NULLIF(ano, '')::INTEGER,
    
    CAST(REPLACE(COALESCE(NULLIF(valor_despesa, ''), '0'), ',', '.') AS NUMERIC),
    COALESCE(status, 'Sem Status')
FROM stage_despesas
WHERE cnpj IS NOT NULL; 

WITH Valor_Por_Periodo AS (
    SELECT 
        cnpj, 
        razao_social,
       
        FIRST_VALUE(valor_despesa) OVER (PARTITION BY cnpj ORDER BY ano, trimestre) as v_inicial,
       
        LAST_VALUE(valor_despesa) OVER (PARTITION BY cnpj ORDER BY ano, trimestre 
            RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as v_final
    FROM despesas_consolidadas
    WHERE valor_despesa >
)
SELECT DISTINCT
    razao_social,
    v_inicial,
    v_final,
    ROUND(((v_final - v_inicial) / NULLIF(v_inicial, 0)) * 100, 2) as crescimento_pct
FROM Valor_Por_Periodo
WHERE v_inicial IS NOT NULL AND v_final IS NOT NULL
ORDER BY crescimento_pct DESC
LIMIT 5;

SELECT 
    o.uf,
    SUM(d.valor_despesa) as despesa_total,
    COUNT(DISTINCT d.cnpj) as qtd_operadoras,
    ROUND(AVG(d.valor_despesa), 2) as media_por_operadora
FROM despesas_consolidadas d
JOIN operadoras o ON d.cnpj = o.cnpj
GROUP BY o.uf
ORDER BY despesa_total DESC
LIMIT 5;

WITH Media_Geral AS (
    SELECT AVG(valor_despesa) as valor_medio_global FROM despesas_consolidadas
),
Frequencia_Acima_Media AS (
    SELECT 
        d.cnpj,
        d.razao_social,
        COUNT(*) FILTER (WHERE d.valor_despesa > (SELECT valor_medio_global FROM Media_Geral)) as vezes_acima
    FROM despesas_consolidadas d
    GROUP BY d.cnpj, d.razao_social
)
SELECT COUNT(*) as total_operadoras_criticas
FROM Frequencia_Acima_Media
WHERE vezes_acima >= 2;

CREATE SCHEMA IF NOT EXISTS staging;   
CREATE SCHEMA IF NOT EXISTS analytics; 

ALTER TABLE public.operadoras SET SCHEMA analytics;
ALTER TABLE public.despesas_consolidadas SET SCHEMA analytics;

CREATE OR REPLACE VIEW analytics.vw_consolidado_geral AS
SELECT 
    o.razao_social,
    o.uf,
    d.ano,
    d.trimestre,
    d.valor_despesa,
    d.status
FROM analytics.despesas_consolidadas d
INNER JOIN analytics.operadoras o ON d.cnpj = o.cnpj;

SELECT * FROM analytics.despesas_consolidadas 
WHERE valor_despesa < 0;

UPDATE analytics.despesas_consolidadas 
SET valor_despesa = 0 
WHERE valor_despesa < 0;

UPDATE analytics.despesas_consolidadas 
SET valor_despesa = ABS(valor_despesa) 
WHERE valor_despesa < 0;

ALTER TABLE analytics.despesas_consolidadas 
ADD CONSTRAINT check_valor_positivo CHECK (valor_despesa >= 0);

SELECT 
    (SELECT COUNT(*) FROM analytics.operadoras) as total_operadoras,
    (SELECT COUNT(*) FROM analytics.despesas_consolidadas) as total_registros_despesas,
    (SELECT SUM(valor_despesa) FROM analytics.despesas_consolidadas) as volume_financeiro_total;

SELECT 
    COUNT(*) as qtd_linhas,
    SUM(valor_despesa) as soma_total,
    (SELECT COUNT(*) FROM analytics.operadoras) as qtd_operadoras
FROM analytics.despesas_consolidadas;

INSERT INTO analytics.operadoras (registro_ans, cnpj, razao_social, modalidade, cidade, uf, data_registro_ans)
VALUES 
('419761', '19541931000125', '18 DE JULHO ADMINISTRADORA DE BENEFÍCIOS LTDA', 'Administradora de Benefícios', 'Além Paraíba', 'MG', '2015-05-19'),
('421545', '22869997000153', '2B ODONTOLOGIA OPERADORA DE PLANOS ODONTOLÓGICOS LTDA', 'Odontologia de Grupo', 'São Paulo', 'SP', '2019-06-13'),
('421421', '27452545000195', '2CARE OPERADORA DE SAÚDE LTDA.', 'Medicina de Grupo', 'Campinas', 'SP', '2018-10-09'),
('418030', '13138885000131', 'A.P.S. ADMINISTRADORA DE BENEFÍCOS LTDA.', 'Administradora de Benefícios', 'São Paulo', 'SP', '2011-05-05'),
('314668', '17505793000101', 'ABERTTA SAÚDE - ASSOCIAÇÃO BENEFICENTE', 'Autogestão', 'Belo Horizonte', 'MG', '1998-12-28');

INSERT INTO analytics.despesas_consolidadas (cnpj, razao_social, trimestre, ano, valor_despesa, status)
VALUES 
('19541931000125', '18 DE JULHO ADMINISTRADORA', 1, 2023, 50000.00, 'OK'),
('19541931000125', '18 DE JULHO ADMINISTRADORA', 2, 2023, 75000.00, 'OK'), -- Crescimento aqui
('22869997000153', '2B ODONTOLOGIA', 1, 2023, 10000.00, 'OK'),
('27452545000195', '2CARE OPERADORA', 1, 2023, 150000.00, 'OK');

SELECT 
    (SELECT COUNT(*) FROM analytics.operadoras) as total_operadoras,
    (SELECT COUNT(*) FROM analytics.despesas_consolidadas) as total_registros_despesas,
    (SELECT SUM(valor_despesa) FROM analytics.despesas_consolidadas) as volume_financeiro_total;

DROP SCHEMA IF EXISTS staging CASCADE;

SET search_path TO analytics, public;