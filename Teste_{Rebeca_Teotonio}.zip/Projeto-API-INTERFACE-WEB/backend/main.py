from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

try:
    df_despesas = pd.read_csv('consolidado_despesas.csv', sep=';')
    df_agregado = pd.read_csv('despesas_agregadas.csv', sep=';')
except FileNotFoundError:
    print("Erro: Arquivos CSV não encontrados na mesma pasta do main.py")

@app.get("/api/operadoras")
async def get_operadoras(page: int = 1, limit: int = 10, q: str = None):
  
    data = df_despesas[['CNPJ', 'RazaoSocial']].drop_duplicates()
    
    if q:
        data = data[data['RazaoSocial'].str.contains(q, case=False) | data['CNPJ'].str.contains(q)]
    
    total = len(data)
    start = (page - 1) * limit
    end = start + limit
    
    items = data.iloc[start:end].to_dict(orient='records')
    
    return {
        "data": items,
        "total": total,
        "page": page,
        "limit": limit
    }

@app.get("/api/operadoras/{cnpj}")
async def get_operadora_detail(cnpj: str):
    op = df_despesas[df_despesas['CNPJ'] == cnpj].head(1)
    if op.empty:
        raise HTTPException(status_code=404, detail="Operadora não encontrada")
    return op[['CNPJ', 'RazaoSocial']].to_dict(orient='records')[0]

@app.get("/api/operadoras/{cnpj}/despesas")
async def get_operadora_expenses(cnpj: str):
    expenses = df_despesas[df_despesas['CNPJ'] == cnpj]
    return expenses[['Ano', 'Trimestre', 'ValorDespesas', 'Status']].to_dict(orient='records')

@app.get("/api/estatisticas")
async def get_stats():
  
    top_5 = df_agregado.nlargest(5, 'Total_Despesas')[['RazaoSocial', 'Total_Despesas']].to_dict(orient='records')
    
    
    dist_uf = df_agregado.groupby('UF')['Total_Despesas'].sum().to_dict()
    
    return {
        "total_geral": float(df_agregado['Total_Despesas'].sum()),
        "media_despesa": float(df_agregado['Total_Despesas'].mean()),
        "top_5": top_5,
        "distribuicao_uf": dist_uf
    }