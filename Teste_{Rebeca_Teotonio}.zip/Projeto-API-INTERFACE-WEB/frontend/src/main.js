import { createApp, ref } from 'vue'

const App = {
  setup() {
    const mensagem = ref('Frontend Conectado!')
    return { mensagem }
  },
  template: `<h1>{{ mensagem }}</h1>`
}

createApp(App).mount('#app')