<template>
  <div class="p-8 bg-gray-100 min-h-screen">
    <h1 class="text-2xl font-bold mb-6">Dashboard de Operadoras</h1>

    <div class="mb-4">
      <input v-model="search" @input="fetchOperadoras" placeholder="Buscar por CNPJ ou Razão Social..." class="p-2 border rounded w-full">
    </div>

    <div class="bg-white rounded shadow overflow-hidden">
      <table class="w-full text-left">
        <thead class="bg-gray-50">
          <tr>
            <th class="p-3">CNPJ</th>
            <th class="p-3">Razão Social</th>
            <th class="p-3">Ações</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="loading"><td colspan="3" class="p-4 text-center">Carregando...</td></tr>
          <tr v-for="op in operadoras" :key="op.CNPJ" class="border-t">
            <td class="p-3">{{ op.CNPJ }}</td>
            <td class="p-3">{{ op.RazaoSocial }}</td>
            <td class="p-3">
              <button @click="verDetalhes(op.CNPJ)" class="text-blue-500 hover:underline">Ver Detalhes</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="flex gap-2 mt-4">
      <button @click="changePage(-1)" :disabled="page === 1" class="px-4 py-2 bg-white border rounded disabled:opacity-50">Anterior</button>
      <span class="py-2">Página {{ page }}</span>
      <button @click="changePage(1)" class="px-4 py-2 bg-white border rounded">Próxima</button>
    </div>

    <div v-if="selectedOp" class="mt-10 p-6 bg-white rounded shadow">
      <h2 class="text-xl font-bold mb-4">Histórico: {{ selectedOp.RazaoSocial }}</h2>
      <canvas id="expensesChart"></canvas>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import Chart from 'chart.js/auto';

const operadoras = ref([]);
const loading = ref(false);
const search = ref('');
const page = ref(1);
const selectedOp = ref(null);
let chartInstance = null;

const fetchOperadoras = async () => {
  loading.ref = true;
  const res = await fetch(`http://localhost:8000/api/operadoras?page=${page.value}&q=${search.value}`);
  const json = await res.json();
  operadoras.value = json.data;
  loading.value = false;
};

const verDetalhes = async (cnpj) => {
  const res = await fetch(`http://localhost:8000/api/operadoras/${cnpj}/despesas`);
  const data = await res.json();
  
  selectedOp.value = operadoras.value.find(o => o.CNPJ === cnpj);
  
 
  setTimeout(() => {
    const ctx = document.getElementById('expensesChart');
    if (chartInstance) chartInstance.destroy();
    chartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: data.map(d => `T${d.Trimestre}/${d.Ano}`),
        datasets: [{ label: 'Despesas', data: data.map(d => d.ValorDespesas), borderColor: '#3b82f6' }]
      }
    });
  }, 100);
};

const changePage = (step) => {
  page.value += step;
  fetchOperadoras();
};

onMounted(fetchOperadoras);
</script>