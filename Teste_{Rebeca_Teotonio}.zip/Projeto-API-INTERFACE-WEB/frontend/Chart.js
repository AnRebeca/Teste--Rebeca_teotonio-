const renderizarGraficoUF = (dadosUF) => {
  const ctx = document.getElementById('graficoUF');
  new Chart(ctx, {
    type: 'bar', 
    data: {
      labels: Object.keys(dadosUF), 
      datasets: [{
        label: 'Despesas por UF',
        data: Object.values(dadosUF)
      }]
    }
  });
}